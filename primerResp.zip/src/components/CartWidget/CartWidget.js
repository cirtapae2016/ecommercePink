import cart from "./assets/cart.svg"

const CartWidget = () => { 
return (
    <div>
        <img src={cart} alt="cart-wdiget" width="20px" />
        0
    </div>
)
};

export default CartWidget;